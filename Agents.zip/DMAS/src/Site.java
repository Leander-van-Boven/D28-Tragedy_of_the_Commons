class Site {

	private double foodMax;
	private double food;
	private int xPosition;
	private int yPosition;
	private Agent agent;
	
	private final double growCoefficient = 2;

	public Site() {
		food = 0;
	}

	public Site(double cap, int x, int y) {
		food = foodMax = cap;
		xPosition = x;
		yPosition = y;
	}

	// Called once every step; determines the growback.
	// Be creative. You can add new parameters, for example.
	public void grow() {
		
		if (this.food == 0) {this.food = 0.1;}
		
		if (this.food != foodMax){			
			//this.food += (foodMax - this.food)/10;
			//this.food += Math.sqrt(foodMax - this.food);
			this.food *= growCoefficient;
		}
		if (this.food > foodMax){
			this.food = foodMax;
		}
	}

	// Use the getFood and setFood methods to let an
	// agent reap this site.
	public double getFood() {
		return food;
	}

	public void setFood(double f) {
		food = f;
	}

	public Agent getAgent() {
		return agent;
	}

	// Use this method to let agents move around.
	public void setAgent(Agent a) {
		agent = a;
	}

	public int getXPosition() {
		return xPosition;
	}

	public int getYPosition() {
		return yPosition;
	}

}